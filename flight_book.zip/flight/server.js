const express = require("express");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const flightsPath = path.join(__dirname, "data", "flights.json");

app.get("/api/flights", (req, res) => {
  const { from, to, date, travelClass, tripType } = req.query;

  fs.readFile(flightsPath, "utf8", (err, data) => {
    if (err) {
      return res.status(500).json({ message: "Error reading flights data" });
    }

    let flights = JSON.parse(data);

    if (from) {
      flights = flights.filter(f => f.from.toLowerCase() === from.toLowerCase());
    }

    if (to) {
      flights = flights.filter(f => f.to.toLowerCase() === to.toLowerCase());
    }

    if (date) {
      flights = flights.filter(f => f.date === date);
    }

    if (travelClass) {
      flights = flights.filter(f => f.class.toLowerCase() === travelClass.toLowerCase());
    }

    if (tripType) {
      flights = flights.filter(f => f.type.toLowerCase() === tripType.toLowerCase());
    }

    res.json(flights);
  });
});

app.get("/api/flights/:id", (req, res) => {
  const flightId = parseInt(req.params.id);

  fs.readFile(flightsPath, "utf8", (err, data) => {
    if (err) {
      return res.status(500).json({ message: "Error reading flights data" });
    }

    const flights = JSON.parse(data);
    const flight = flights.find(f => f.id === flightId);

    if (!flight) {
      return res.status(404).json({ message: "Flight not found" });
    }

    res.json(flight);
  });
});

app.post("/api/book", (req, res) => {
  const { name, email, seat, baggage, flightId } = req.body;

  if (!name || !email || !seat || !flightId) {
    return res.status(400).json({ success: false, message: "Missing fields" });
  }

  const bookingId = "SWB" + Math.floor(Math.random() * 100000);

  res.json({
    success: true,
    bookingId,
    message: "Booking Successful! Your flight has been confirmed."
  });
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});