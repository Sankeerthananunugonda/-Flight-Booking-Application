const params = new URLSearchParams(window.location.search);

const from = params.get("from");
const to = params.get("to");
const date = params.get("date");
const travelClass = params.get("travelClass");
const tripType = params.get("tripType");

fetch(`/api/flights?from=${from}&to=${to}&date=${date}&travelClass=${travelClass}&tripType=${encodeURIComponent(tripType)}`)
  .then(res => res.json())
  .then(flights => {
    const container = document.getElementById("resultsContainer");

    if (!flights.length) {
      container.innerHTML = `<div class="flight-card">No flights found</div>`;
      return;
    }

    flights.forEach(flight => {
      const card = document.createElement("div");
      card.className = "flight-card";
      card.innerHTML = `
        <h3>${flight.airline} · ${flight.flightNumber}</h3>
        <p>${flight.from} → ${flight.to}</p>
        <p>${flight.departure} - ${flight.arrival}</p>
        <p>Duration: ${flight.duration}</p>
        <p>Class: ${flight.class}</p>
        <p class="price">$${flight.price}</p>
        <button onclick="bookFlight(${flight.id})">Book Now</button>
      `;
      container.appendChild(card);
    });
  });

function bookFlight(id) {
  window.location.href = `booking.html?id=${id}`;
}