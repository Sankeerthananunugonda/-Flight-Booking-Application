const tripList = document.getElementById("tripList");
const cancelledList = document.getElementById("cancelledList");
const upcomingCount = document.getElementById("upcomingCount");
const historyCount = document.getElementById("historyCount");
const cancelledCount = document.getElementById("cancelledCount");

let bookedTrips = JSON.parse(localStorage.getItem("bookedTrips")) || [];
let cancelledTrips = JSON.parse(localStorage.getItem("cancelledTrips")) || [];

// If only one bookingData exists from your current project, convert it into trip format
const singleBooking = JSON.parse(localStorage.getItem("bookingData"));
if (singleBooking && bookedTrips.length === 0) {
  bookedTrips.push({
    bookingId: singleBooking.bookingId || "SW201",
    airline: "SkyWard Airlines",
    flightNumber: "SW 201",
    route: "JFK → LAX",
    date: "2026-04-15",
    status: "confirmed",
    price: "$319"
  });
  localStorage.setItem("bookedTrips", JSON.stringify(bookedTrips));
}

function renderTrips() {
  bookedTrips = JSON.parse(localStorage.getItem("bookedTrips")) || [];
  cancelledTrips = JSON.parse(localStorage.getItem("cancelledTrips")) || [];

  upcomingCount.textContent = bookedTrips.length;
  historyCount.textContent = 0;
  cancelledCount.textContent = cancelledTrips.length;

  if (bookedTrips.length === 0) {
    tripList.innerHTML = `<div class="empty-box">No upcoming trips.</div>`;
  } else {
    tripList.innerHTML = bookedTrips.map((trip, index) => `
      <div class="trip-card">
        <div class="trip-top">
          <div class="trip-left">
            <div class="plane-box">✈</div>
            <div>
              <h3>${trip.airline} · ${trip.flightNumber}</h3>
              <p>${trip.route} · ${trip.date}</p>
            </div>
          </div>

          <div class="trip-right">
            <span class="status-badge">${trip.status}</span>
            <span class="trip-price">${trip.price}</span>
          </div>
        </div>

        <div class="trip-actions">
          <button class="eticket-btn" onclick="downloadTicket('${trip.bookingId}')">⬇ E-Ticket</button>
          <button class="cancel-trip-btn" onclick="cancelTrip(${index})">✕ Cancel</button>
        </div>
      </div>
    `).join("");
  }

  if (cancelledTrips.length === 0) {
    cancelledList.innerHTML = `No cancelled trips.`;
  } else {
    cancelledList.innerHTML = cancelledTrips.map(trip => `
      <div class="trip-card cancelled-card">
        <div class="trip-top">
          <div class="trip-left">
            <div class="plane-box">✈</div>
            <div>
              <h3>${trip.airline} · ${trip.flightNumber}</h3>
              <p>${trip.route} · ${trip.date}</p>
            </div>
          </div>

          <div class="trip-right">
            <span class="cancelled-badge">cancelled</span>
            <span class="trip-price">${trip.price}</span>
          </div>
        </div>
      </div>
    `).join("");
  }
}

function cancelTrip(index) {
  const trips = JSON.parse(localStorage.getItem("bookedTrips")) || [];
  const cancelled = JSON.parse(localStorage.getItem("cancelledTrips")) || [];

  const removedTrip = trips.splice(index, 1)[0];
  cancelled.push({ ...removedTrip, status: "cancelled" });

  localStorage.setItem("bookedTrips", JSON.stringify(trips));
  localStorage.setItem("cancelledTrips", JSON.stringify(cancelled));

  alert("Trip cancelled successfully.");
  renderTrips();
}

function downloadTicket(bookingId) {
  alert("E-Ticket download started for Booking ID: " + bookingId);
}

document.querySelectorAll(".tab-btn").forEach(button => {
  button.addEventListener("click", () => {
    document.querySelectorAll(".tab-btn").forEach(btn => btn.classList.remove("active-tab"));
    document.querySelectorAll(".tab-content").forEach(tab => tab.classList.remove("active-content"));

    button.classList.add("active-tab");

    const selectedTab = button.dataset.tab;
    document.getElementById(selectedTab + "Tab").classList.add("active-content");
  });
});

renderTrips();