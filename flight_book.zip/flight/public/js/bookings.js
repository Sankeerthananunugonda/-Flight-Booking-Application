const urlParams = new URLSearchParams(window.location.search);
const flightId = urlParams.get("id");

fetch(`/api/flights/${flightId}`)
  .then(res => res.json())
  .then(flight => {
    document.getElementById("flightDetails").innerHTML = `
      <h3>${flight.airline} · ${flight.flightNumber}</h3>
      <p>${flight.from} → ${flight.to}</p>
      <p>${flight.date}</p>
      <p>${flight.departure} - ${flight.arrival}</p>
      <p>${flight.class}</p>
      <p class="price">$${flight.price}</p>
    `;
  });
  

document.getElementById("bookingForm").addEventListener("submit", function (e) {
  e.preventDefault();

  const bookingData = {
    flightId: parseInt(flightId),
    name: document.getElementById("name").value,
    email: document.getElementById("email").value,
    seat: document.getElementById("seat").value,
    baggage: document.getElementById("baggage").value
  };

  fetch("/api/book", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(bookingData)
  })
    .then(res => res.json())
    .then(data => {
      localStorage.setItem("bookingData", JSON.stringify(data));
      alert("Booking Successful! Your flight has been confirmed.");
      window.location.href = "confirmation.html";
    });
});