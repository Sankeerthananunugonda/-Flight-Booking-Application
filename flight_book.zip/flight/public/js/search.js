document.querySelectorAll(".trip-btn").forEach(button => {
  button.addEventListener("click", function () {
    document.querySelectorAll(".trip-btn").forEach(btn => btn.classList.remove("active"));
    this.classList.add("active");
    document.getElementById("tripType").value = this.dataset.type;
  });
});

document.getElementById("searchForm").addEventListener("submit", function (e) {
  e.preventDefault();

  const tripType = document.getElementById("tripType").value;
  const from = document.getElementById("from").value;
  const to = document.getElementById("to").value;
  const date = document.getElementById("date").value;
  const passengers = document.getElementById("passengers").value;
  const travelClass = document.getElementById("travelClass").value;

  const query = new URLSearchParams({
    tripType,
    from,
    to,
    date,
    passengers,
    travelClass
  });

  window.location.href = `results.html?${query.toString()}`;
});