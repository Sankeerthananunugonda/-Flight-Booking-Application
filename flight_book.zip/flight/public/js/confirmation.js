const bookingData = JSON.parse(localStorage.getItem("bookingData"));
const confirmationBox = document.getElementById("confirmationBox");

if (bookingData) {
  confirmationBox.innerHTML = `
    <h3>${bookingData.message}</h3>
    <p>Booking ID: ${bookingData.bookingId}</p>
  `;
}