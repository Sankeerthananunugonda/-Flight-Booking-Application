const mysql = require("mysql2");

const db = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "your_mysql_password",
    database: "flight_booking_db"
});

db.connect((err) => {
    if(err){
        console.log("Database connection failed:", err);
    }else{
        console.log("Connected to MySQL database");
    }
});

module.exports = db;